package com.example.android.s56882_question2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        <Button
        android:onClick="clickButton"/>

        fun clickButton(v: View){
            val mToast = Toast.makeText(applicationContext,"button 3 clicked", Toast.LENGTH_SHORT)
            mToast.show()
        }
    }
}