package com.example.android.s56882_question2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class secondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val sp = this.getSharedPreferences("ahmad",MODE_PRIVATE)

        val iname = findViewById<EditText>(R.id.Username)
        val iage = findViewById<EditText>(R.id.Password)

        iname.setText(sp.getString("username",null))
        iage.setText(sp.getString("password",null))
    }

    override fun onPause() {
        super.onPause()
        val iname = findViewById<EditText>(R.id.Username)
        val ipassword = findViewById<EditText>(R.id.Password)

        val sp = this.getSharedPreferences( "ahmad",MODE_PRIVATE)
        val editor = sp.edit()
        editor.putString("name",iname.text.toString())
        editor.putString("name",iname.text.toString())
        editor.commit()
    }
}